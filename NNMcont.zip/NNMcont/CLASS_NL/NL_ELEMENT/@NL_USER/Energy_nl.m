function E = Energy_nl(obj,x)

E=Energy_nl_user(x);

end
