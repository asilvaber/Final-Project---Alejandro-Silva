function obj = NL_LAW_LINPIECEWISE(k1,k2,a)

obj.k1=k1;
obj.k2=k2;
obj.a=a;
obj=class(obj,'NL_LAW_LINPIECEWISE');

end

